package com.example.e_shop.PhoneLoginRegister;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.blogspot.atifsoftwares.animatoolib.Animatoo;
import com.example.e_shop.EmailLoginRegister.EmailLoginActivity;
import com.example.e_shop.EmailLoginRegister.EmailRegisterActivity;
import com.example.e_shop.MainActivity;
import com.example.e_shop.R;

public class PhoneLoginActivity extends AppCompatActivity {
    private EditText phone;
    private Button btnReg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phone_login);
        init();
    }

    private void init() {

        phone=(EditText) findViewById(R.id.phone);
        btnReg=(Button) findViewById(R.id.button2);
        btnReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user_phone=phone.getText().toString().trim();

                if(TextUtils.isEmpty(user_phone))
                {
                    phone.setError("phn num is null");
                }
                else
                {
                    Toast.makeText(PhoneLoginActivity.this, "Success", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }


    public void goToRegister(View view) {

        Intent intent= new Intent(PhoneLoginActivity.this,PhoneRegisterActivity.class);
        startActivity(intent);
        Animatoo.animateSlideLeft(this);
        finish();
    }


    public void backTomainpage(View view) {
        Intent intent= new Intent(PhoneLoginActivity.this, MainActivity.class);
        startActivity(intent);
        Animatoo.animateSlideLeft(this);
        finish();
    }
}
