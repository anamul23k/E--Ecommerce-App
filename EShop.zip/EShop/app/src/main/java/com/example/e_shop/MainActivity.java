package com.example.e_shop;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;

import com.blogspot.atifsoftwares.animatoolib.Animatoo;
import com.example.e_shop.Adapter.PlateAdapter;
import com.example.e_shop.EmailLoginRegister.EmailRegisterActivity;
import com.example.e_shop.Modles.PlateModel;
import com.example.e_shop.PhoneLoginRegister.PhoneRegisterActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private List<PlateModel>plateModelList;
    private PlateAdapter plateAdapter;
    private LinearLayout emailContinue;
    private LinearLayout emailContinueBtn;
    private LinearLayout phoneContinue;
    private LinearLayout phoneContinueBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ///////hide status bar/////////

        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.KITKAT){

            Window w =getWindow();
            w.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        }

           emailContinue=(LinearLayout) findViewById(R.id.linear2);
        phoneContinue=(LinearLayout)findViewById(R.id.linear1);
        recyclerView=(RecyclerView) findViewById(R.id.recyclerView);
        LinearLayoutManager layoutManager=new LinearLayoutManager(this);
        layoutManager.setOrientation(RecyclerView.HORIZONTAL);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setKeepScreenOn(true);
        recyclerView.setHasFixedSize(true);
        plateModelList=new ArrayList<>();
       plateModelList.add(new PlateModel(R.drawable.tow));
       plateModelList.add(new PlateModel(R.drawable.tow1));
       plateModelList.add(new PlateModel(R.drawable.tow));
       plateModelList.add(new PlateModel(R.drawable.tow1));
       plateModelList.add(new PlateModel(R.drawable.tow));
       plateModelList.add(new PlateModel(R.drawable.tow1));
       plateModelList.add(new PlateModel(R.drawable.tow));




       plateAdapter =new PlateAdapter(plateModelList, this);
       recyclerView.setAdapter(plateAdapter);
       plateAdapter.notifyDataSetChanged();
       ///////call auto scroll///
        autoScroll();

        //////////////continue with email///////
        emailContinue.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this, EmailRegisterActivity.class);
                startActivity(intent);
                Animatoo.animateSlideDown(MainActivity.this);
            }

        });

//////////////phone contrinue///////////
        phoneContinue.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this, PhoneRegisterActivity.class);
                startActivity(intent);
                Animatoo.animateSlideDown(MainActivity.this);
            }

        });
    }

    public void autoScroll(){
      final int  speedScroll = 0;
        final Handler handler  = new Handler();
        final Runnable runnable = new Runnable() {
            int count = 0;
            @Override
            public void run() {
                if(count == plateAdapter.getItemCount())
                    count = 0;
                if(count < plateAdapter.getItemCount()){
                    recyclerView.smoothScrollToPosition(++count);
                    handler.postDelayed(this,speedScroll);
                }
            }
        };
        handler.postDelayed(runnable,speedScroll);
    }

    public void goToHomepage(View view) {

        Intent intent=new Intent(MainActivity.this, HomeActivity.class);
        startActivity(intent);
        finish();
        Animatoo.animateFade(this);
    }
}
