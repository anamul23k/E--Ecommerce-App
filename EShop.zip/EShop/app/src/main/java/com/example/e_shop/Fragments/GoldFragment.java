package com.example.e_shop.Fragments;

import android.os.Bundle;

import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.e_shop.R;
import com.google.android.material.navigation.NavigationView;

/**
 * A simple {@link Fragment} subclass.
 */
public class GoldFragment extends Fragment implements View.OnClickListener{

    public GoldFragment() {
        // Required empty public constructor
    }
    DrawerLayout drawerLayout;
    ImageView navigationBar;
    NavigationView navigationView;
    private View view;
    private RelativeLayout loginSignUp,bookmark,eShop,aboutUs,feedback;
    private TextView yourOrders,favarite,address,help;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view= inflater.inflate(R.layout.fragment_gold, container, false);

        onSetNavigationDrawerEvents();
        return view;


    }
    private void onSetNavigationDrawerEvents() {
        drawerLayout = (DrawerLayout) view.findViewById(R.id.drawerLayout);
        navigationView = (NavigationView) view.findViewById(R.id.navigationView);

        navigationBar = (ImageView) view.findViewById(R.id.navigationBar);


        loginSignUp=(RelativeLayout) view.findViewById(R.id.relativeLayout);
        bookmark=(RelativeLayout) view.findViewById(R.id.relativeLayout1);
        eShop=(RelativeLayout) view.findViewById(R.id.relativeLayout2);
        aboutUs=(RelativeLayout) view.findViewById(R.id.relativeLayout4);
        feedback=(RelativeLayout) view.findViewById(R.id.relativeLayout5);



        yourOrders=(TextView) view.findViewById(R.id.yourOrders);
        favarite=(TextView) view.findViewById(R.id.favarite);
        address=(TextView) view.findViewById(R.id.address);
        help=(TextView) view.findViewById(R.id.help);

        navigationBar.setOnClickListener(this);
        loginSignUp.setOnClickListener(this);
        bookmark.setOnClickListener(this);
        eShop.setOnClickListener(this);
        aboutUs.setOnClickListener(this);
        feedback.setOnClickListener(this);


        yourOrders.setOnClickListener(this);
        favarite.setOnClickListener(this);
        address.setOnClickListener(this);
        help.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.navigationBar:
                drawerLayout.openDrawer(navigationView, true);
                break;
            case R.id.relativeLayout:
                Toast.makeText(getContext(), "loginSignUp", Toast.LENGTH_SHORT).show();
                break;
            case R.id.relativeLayout1:
                Toast.makeText(getContext(), " bookmark", Toast.LENGTH_SHORT).show();
                break;
            case R.id.relativeLayout2:
                Toast.makeText(getContext(), " eShop", Toast.LENGTH_SHORT).show();
                break;
            case R.id.relativeLayout4:
                Toast.makeText(getContext(), "aboutUs", Toast.LENGTH_SHORT).show();
                break;
            case R.id.relativeLayout5:
                Toast.makeText(getContext(), "feedback", Toast.LENGTH_SHORT).show();
                break;
            case R.id.yourOrders:
                Toast.makeText(getContext(), "yourOrders", Toast.LENGTH_SHORT).show();
                break;

            case R.id.favarite:
                Toast.makeText(getContext(), "favarite", Toast.LENGTH_SHORT).show();
                break;
            case R.id.address:
                Toast.makeText(getContext(), "address", Toast.LENGTH_SHORT).show();
                break;
            case R.id.help:
                Toast.makeText(getContext(), "help", Toast.LENGTH_SHORT).show();
                break;
        }
    }

    private void showToast(String message){
        Toast.makeText(getContext(),message,Toast.LENGTH_SHORT).show();
    }


}

