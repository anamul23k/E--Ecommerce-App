package com.example.e_shop;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;
import android.view.WindowManager;

public class eshopActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eshop);

        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.KITKAT){

            Window w =getWindow();
            w.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        }


        new Handler().postDelayed(new Runnable(){
            @Override
            public void run(){
                Intent Intent=new Intent(eshopActivity.this,MainActivity.class);
                startActivity(Intent);
                finish();
            }



        },3000);

    }


}
